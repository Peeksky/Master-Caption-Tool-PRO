# Master Caption Tool PRO

A lightweight, single-page caption and text utility that can be hosted on GitHub Pages.

## Features

- Text case conversion and text cleanup tools
- List-to-comma and comma-to-list conversion
- Sort, randomize, reverse, copy, download, undo, and clear actions
- Word, character, and line statistics
- Dark/light theme
- Voice typing with language options (browser support required)

## Run locally

Open `index.html` in a modern browser. Voice typing may not work when opened directly as a local file; use HTTPS hosting such as GitHub Pages for best compatibility.

## Publish with GitHub Pages

1. Create a new repository on GitHub.
2. Upload `index.html` and `README.md` to the repository's root folder.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish the site. The published URL will appear in the Pages settings.

## Voice typing notes

Voice typing uses the browser's Web Speech API. Support and recognition quality vary by browser, device, language, network, and browser service. Use a current version of Chrome or Edge and allow microphone access. HTTPS is generally required for microphone and speech features. Hinglish transliteration is heuristic and may need manual corrections.

## Privacy

This is a client-side HTML tool. Text processing is performed in the browser. Voice recognition is provided by the browser's speech service and may send audio to that service according to the browser/provider's policies.
